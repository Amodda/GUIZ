
import com.sun.javafx.application.LauncherImpl;

import handler.DataWriter;
import javafx.application.Application;
import javafx.application.Preloader;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

// Classe Main che imposta la risoluzione della finestra di gioco ad 800x600
// è stata realizzata a partire dall'esempio di base fornito con IntelliJ IDEA.
public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("main_menu.fxml"));
        primaryStage.setTitle("GUIz");
        primaryStage.setScene(new Scene(root, 700, 500));
        primaryStage.show();

        //System.out.println(Main.class.getResource("game.fxml"));
    }
/*
    @Override
    public void init() throws Exception {
        
        // Perform some heavy lifting (i.e. database start, check for application updates, etc. )
        for (double i = 1; i <= 5; i++) {
            double progress = i / 10;
            System.out.println("progress: " + progress);
            LauncherImpl.notifyPreloader(this, new Preloader.ProgressNotification(progress));
            Thread.sleep(500);
        }

    }*/

    public static void main(String[] args) {
        new DataWriter(); // Ripristina le impostazioni di default ad ogni esecuzione
        //LauncherImpl.launchApplication(Main.class, MyPreloader.class, args);
        launch(args);
    }
}
