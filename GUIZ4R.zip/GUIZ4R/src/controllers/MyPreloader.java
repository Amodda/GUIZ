/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;




import javafx.application.Preloader;

import javafx.scene.Scene;

import javafx.scene.layout.BorderPane;

import javafx.stage.Stage;


public class MyPreloader extends Preloader {
      
      
    
    Stage stage;
 
    private Scene createPreloaderScene() {
        
        
        BorderPane p = new BorderPane();
        
        p.setStyle("-fx-background-color: black;");
        
        return new Scene(p, 500, 400);        
    }
    
    public void start(Stage stage) throws Exception {
        this.stage = stage;
        stage.setScene(createPreloaderScene());        
        stage.show();
    }
    
    @Override
    public void handleProgressNotification(ProgressNotification pn) {
        
    }
 
    @Override
    public void handleStateChangeNotification(StateChangeNotification evt) {
        if (evt.getType() == StateChangeNotification.Type.BEFORE_START) {
            stage.hide();
        }
    }    
}

/*
    private Stage preloaderStage;
    private Scene scene;
    
    public MyPreloader() {
        
    }

    @Override
    public void init() throws Exception {               
                                         
    //Parent root1 = FXMLLoader.load(getClass().getResource("splashScreen.fxml"));               
   // scene = new Scene(FXMLLoader.load(getClass().getResource("splashScreen.fxml")));                       
                
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        
       this.preloaderStage = primaryStage;
       scene = new Scene(FXMLLoader.load(getClass().getResource("splashScreen.fxml")));
        // Set preloader scene and show stage.
        preloaderStage.setScene(scene);  
        //preloaderStage.initStyle(StageStyle.UNDECORATED);
        preloaderStage.show();
        
        
      
    }

    @Override
public void handleStateChangeNotification(StateChangeNotification stateChangeNotification) {
      if (stateChangeNotification.getType() == Type.BEFORE_START) {
         preloaderStage.hide();
      }
   }

}
*/

/*
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class MyPreloader implements Initializable {
    
    @FXML AnchorPane ap;
      
    class ShowSplashScreen extends Thread{
        @Override
        public void run(){
            try {
                System.out.println("ciao");
                Thread.sleep(5000);
                
                Platform.runLater(() -> {
                    Stage stage = new Stage();
                    Parent root = null;
                    
                    try {
                        root = FXMLLoader.load(getClass().getResource("main_menu.fxml"));
                        
                    } catch (IOException ex) {
                        Logger.getLogger(MyPreloader.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    Scene scene = new Scene(root);
                    stage.setScene(scene);
                    stage.show();
                    ap.getScene().getWindow().hide();
                });                
            } catch (InterruptedException ex) {
                Logger.getLogger(MyPreloader.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        new ShowSplashScreen().start();
    }   
}*/