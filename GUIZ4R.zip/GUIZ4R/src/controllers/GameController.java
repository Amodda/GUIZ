package controllers;

import handler.DataReader;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.StringTokenizer;
import java.util.Timer;
import java.util.TimerTask;
import javafx.application.Platform;

public class GameController implements SceneSwitch {

    @FXML
    TextField player1;
    @FXML
    TextField player2;
    @FXML
    Text score1;
    @FXML
    Text score2;
    @FXML
    Text statusText;
    @FXML
    Text questionsLeft;
    @FXML
    Text questionDifficulty;
    @FXML
    Text levelDifficulty;
    @FXML
    Text currentPlayer;
    @FXML
    Button startGame;
    @FXML
    Button b1;
    @FXML
    Button b2;
    @FXML
    Button b3;
    @FXML
    Button b4;
    @FXML
    Button nextRound;
    @FXML
    Button goBackFromGame;

    private ArrayList<String> questionArray;
    private ArrayList<String> question = new ArrayList<>();

    private ArrayList<String> answer = new ArrayList<>();
    private ArrayList<String> answers = new ArrayList<>();

    private ArrayList<String> level = new ArrayList<>();

    private ArrayList<String> pointArray = new ArrayList<>();

    private int player = 0;
    private int remainingQuestions = 0;

    private int playerOneScore;
    private int playerTwoScore;

    private String playerOneName = "";
    private String playerTwoName = "";

    private String answerFromArray = "";
    private String correctA = "";
    private String answerButtonText = "";

    private ArrayList<String> settings = new ArrayList<String>();

    private Random randomQuestionNumber = new Random();
    private int randomQuestion = 0;
    private String imp;

    ControlPanelBoard a = new ControlPanelBoard();

    @FXML
    public void handleGoBack(ActionEvent click) throws IOException {
        switchScene(click, "src/main_menu.fxml");
    }

    @FXML
    private void handleStartGame() throws IOException {
        // Memorizza il nome dei giocatori
        playerOneName = player1.getText();
        playerTwoName = player2.getText();

        if (playerOneName.equals("")) {
            playerOneName = "Player 1";
        }
        if (playerTwoName.equals("")) {
            playerTwoName = "Player 2";
        }

        player1.setDisable(true);
        player2.setDisable(true);

        score1.setText("Punteggio " + playerOneName + ": 0");
        score2.setText("Punteggio " + playerTwoName + ": 0");

        //levelDifficulty.setText("Livello: " + difficultyLevel);
        playerOneScore = 0;
        playerTwoScore = 0;

        imp = a.readImport();
        System.out.println(imp);
        // Popola gli Array sfruttando il DataReader per la lettura dei file.
        questionArray = DataReader.readQuestions(); // Contiene tutte le domande.
        settings = DataReader.readSettings();
        
        String difficultyLevel = settings.get(0);
        int amountOfQuestions = Integer.parseInt(settings.get(1));
        boolean points = Boolean.parseBoolean(settings.get(2));
        
    
        StringTokenizer st1;
        
        for (int i = 0; i < questionArray.size() - 1; i++) {
            st1 = new StringTokenizer(questionArray.get(i), ";");
            while (st1.hasMoreTokens()) {
                question.add(st1.nextToken());

                answer.add(st1.nextToken());
                String x = st1.nextToken();
                level.add(x);

                pointArray.add(x);

            }
        }

       

        //answerArray = DataReader.readAnswers(); // Contiene tutte le risposte.
        //levelArray = DataReader.readLevels(); // Contiene tutti i livelli di difficoltà.
        // Questo Array verrà manipolato per assegnare i punti in base al livello.
// Imposta il livello di difficoltà delle domande in base a quanto definito nelle "Impostazioni".
        // Scansiona il levelArray dal fondo e rimuove tutte ciò che è diverso rispetto alla difficoltà prescelta,
        // poi rimuove gli elementi con lo stesso indice anche dagli altri array, per tenerli tutti "allineati".
        if (!difficultyLevel.equalsIgnoreCase("Mix")) {
            if (difficultyLevel.equalsIgnoreCase("Facile")) {
                for (int i = question.size() - 1; i >= 0; i--) {
                    if (!level.get(i).equalsIgnoreCase("FACILE")) {
                        questionArray.remove(i);
                        question.remove(i);
                        answer.remove(i);
                        level.remove(i);
                        pointArray.remove(i);
                    }
                }
            }
            if (difficultyLevel.equalsIgnoreCase("Media")) {
                for (int i = level.size() - 1; i >= 0; i--) {
                    if (!level.get(i).equalsIgnoreCase("MEDIA")) {
                        questionArray.remove(i);
                        question.remove(i);
                        answer.remove(i);
                        level.remove(i);
                        pointArray.remove(i);
                    }
                }
            }
            if (difficultyLevel.equalsIgnoreCase("Difficile")) {
                for (int i = level.size() - 1; i >= 0; i--) {
                    if (!level.get(i).equalsIgnoreCase("DIFFICILE")) {
                        questionArray.remove(i);
                        question.remove(i);
                        answer.remove(i);
                        level.remove(i);
                        pointArray.remove(i);
                    }
                }
            }
        }

        // Imposta il numero di domande a cui rispondere, a condizione che il valore sia
        // diverso da zero e che il numero inserito non sia più grande della dimensione dell'array.
        // La scansione parte sempre dal fondo dell'array ed il ciclo eliminerà da tutti gli array tante
        // domande fino a raggiungere il valore scelto dall'utente.
        if (amountOfQuestions != 0 && question.size() > amountOfQuestions) {
            for (int i = question.size() - 1; i >= amountOfQuestions; i--) {
                questionArray.remove(i);
                question.remove(i);
                answer.remove(i);
                level.remove(i);
                pointArray.remove(i);
            }
        }

        // Modifica il contenuto di pointArray, popolato con i vari "Facile, Media, Difficile",
        // assegnando un valore da 1 a 3 a seconda della difficoltà della domanda. Se l'utente non
        // avrà selezionato l'opzione punti bonus "Si" nelle "Impostazioni" allora il pointArray verrà
        // settato con i tutti i valori a 1.
        if (points == true) {
            for (int i = pointArray.size() - 1; i >= 0; i--) {
                if (pointArray.get(i).equalsIgnoreCase("FACILE")) {
                    pointArray.set(i, "1");
                } else if (level.get(i).equalsIgnoreCase("MEDIA")) {
                    pointArray.set(i, "2");
                } else if (level.get(i).equalsIgnoreCase("DIFFICILE")) {
                    pointArray.set(i, "3");
                }
            }
        } else {
            for (int i = pointArray.size() - 1; i >= 0; i--) {
                pointArray.set(i, "1");
            }
        }

        player = 1; // Inizia il primo giocatore, ovviamente. Ready Player One ;-)

        // Gestisce e mostra la prima domanda, questa parte di codice verrà utilizzata solo per avviare il programma,
        // dopodichè i turni verranno gestiti da handleButtonNext, fino alla proclamazione del vincitore (o del pareggio).
        randomQuestion = randomQuestionNumber.nextInt(question.size()); // Genera un numero casuale per estrarre una domanda a caso.

        StringTokenizer st2;
        //System.out.println(randomQuestion);
        st2 = new StringTokenizer(answer.get(randomQuestion), "-");
        //System.out.println(answer.get(randomQuestion));
        while (st2.hasMoreTokens()) {
            answers.add(st2.nextToken());
        }
        correctA = answers.get(0);
        //System.out.println(correctA);
        Collections.shuffle(answers);
        //System.out.println(answers);
        b1.setText(answers.get(0));
        b2.setText(answers.get(1));
        b3.setText(answers.get(2));
        b4.setText(answers.get(3));
        /*
        System.out.println(randomQuestion);
        System.out.println("q"+question.size());
        System.out.println("l"+level.size());
        System.out.println("a"+answer.size());
        System.out.println("p"+pointArray.size());
         */
        statusText.setText(question.get(randomQuestion)); // Mostra la domanda a cui rispondere.
        questionDifficulty.setText("Domanda: " + level.get(randomQuestion)); // Mostra la difficoltà della domanda.

        currentPlayer.setText("Giocatore: " + playerOneName);
        remainingQuestions = question.size() - 1; // Aggiorna il contatore con il numero di domande mancanti,
        questionsLeft.setText(remainingQuestions + " domande mancanti"); // e lo mostra a video settandolo .setText

        b1.setDisable(false);
        b2.setDisable(false);
        b3.setDisable(false);
        b4.setDisable(false);
        answers.clear();
        startGame.setDisable(true);
    }

    @FXML // Gestisce il funzionamento dei tasti per le risposte, i turni di risposta, vari messaggi di stato.
    private void handleButtonAnswer(ActionEvent event) {

        Button answerButtonClicked = (Button) event.getSource();
        answerButtonText = answerButtonClicked.getText();

        // Recupera il valore della domanda generata a caso con Random
        // in modo che vi sia corrispondenza con la risposta.
        // Il metodo .get(randomQuestion) è stato sfruttato all'interno del
        // programma in varie parti al fine di tenere tutti i risultati estratti
        // dagli array allineati e coerenti fra loro.
        int point = Integer.parseInt(pointArray.get(randomQuestion)); // Assegna alla variabile point il punteggio.
        System.out.println(point);
        System.out.println("Correct A: " + correctA);
        if (correctA.equals(answerButtonText)) {
            statusText.setText("Correct! " + point + " point !");
            if (player == 1) {
                playerOneScore = playerOneScore + point;
                score1.setText("Punteggio " + playerOneName + ": " + playerOneScore);
            } else if (player == 2) {
                playerTwoScore = playerTwoScore + point;
                score2.setText("Punteggio " + playerTwoName + ": " + playerTwoScore);
            }
        } else {
            statusText.setText("Sbagliato! Nessun punto!");
        }

        // Dopo ogni turno di domande i tasti vengono abilitati/disabilitati per il turno successivo.
        //nextRound.setDisable(true);
        b1.setDisable(true);
        b2.setDisable(true);
        b3.setDisable(true);
        b4.setDisable(true);
        Timer time = new Timer();
        time.schedule(new TimerTask() {
            @Override
            public void run() {
                Platform.runLater(() -> {
                    next();
                });
            }
        }, 1500);

    }

    @FXML // Gestisce il funzionamento del tasto "prossima domanda", il giocatore corrente, vari messaggi di stato, gli array, etc.
    private void next() {

        if (player == 1) {
            player = 2;
            currentPlayer.setText("Giocatore corrente: " + playerTwoName);
        } else if (player == 2) {
            player = 1;
            currentPlayer.setText("Giocatore corrente: " + playerOneName);
        }

        questionArray.remove(randomQuestion); // Rimuove la domanda a cui si è già risposto dall'array.
        question.remove(randomQuestion);
        answer.remove(randomQuestion); // Rimuove la risposta a fini di allineamento degli array.
        level.remove(randomQuestion); // Rimuove il livello a fini di allineamento degli array.
        pointArray.remove(randomQuestion);

        // Rimuove il punto a  fini di allineamento degli array.
        remainingQuestions = questionArray.size() - 1; // Aggiorna il contatore con il numero di domande mancanti,
        questionsLeft.setText(remainingQuestions + " domande mancanti"); // e lo mostra a video settandolo .setText

        if (!question.isEmpty()) {
            randomQuestion = randomQuestionNumber.nextInt(question.size());

            StringTokenizer st2;
            //System.out.println(randomQuestion);
            st2 = new StringTokenizer(answer.get(randomQuestion), "-");
            //System.out.println(answer.get(randomQuestion));
            while (st2.hasMoreTokens()) {
                answers.add(st2.nextToken());
            }
            correctA = answers.get(0);
            //System.out.println(correctA);
            Collections.shuffle(answers);
            //System.out.println(answers);
            b1.setText(answers.get(0));
            b2.setText(answers.get(1));
            b3.setText(answers.get(2));
            b4.setText(answers.get(3));

            statusText.setText(question.get(randomQuestion)); // Mostra la domanda a cui rispondere.
            questionDifficulty.setText("Domanda: " + level.get(randomQuestion)); // Mostra la difficoltà della domanda.
            //nextRound.setDisable(true);
            b1.setDisable(false);
            b2.setDisable(false);
            b3.setDisable(false);
            b4.setDisable(false);
            answers.clear();
        } else {
            if (playerOneScore > playerTwoScore) {
                questionsLeft.setText("Game Over. Vince: " + playerOneName);
            } else if (playerTwoScore > playerOneScore) {
                questionsLeft.setText("Game Over. Vince: " + playerTwoName);
            } else {
                questionsLeft.setText("La partita è finita in pareggio! ");
            }
            //nextRound.setDisable(true);
            startGame.setDisable(false);
            b1.setDisable(true);
            b2.setDisable(true);
            b3.setDisable(true);
            b4.setDisable(true);
        }
    }
}
