package controllers;

import java.io.File;
import java.io.FileOutputStream;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;

import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.StringTokenizer;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.stage.FileChooser;

// Gestisce il salvataggio delle "Impostazioni" una delle parti più importanti dell'intero programma.
// Tutte le scelte fatte dall'utente nella GUI vengono salvate in differenti file di testo i cui dati
// verranno letti ed elaborati dal GameController.
public class ControlPanelBoard implements SceneSwitch {

    @FXML
    TextField questionsAmount;
    @FXML
    RadioButton easyRadio;
    @FXML
    RadioButton mediumRadio;
    @FXML
    RadioButton hardRadio;
    @FXML
    RadioButton mixRadio;
    @FXML
    RadioButton yesRadio;
    @FXML
    RadioButton noRadio;
    @FXML
    Label labelSaved;
    @FXML
    Label labelError;
    @FXML
    Label filePath;
    @FXML
    ToggleGroup difficultyLevel;
    @FXML
    ToggleGroup pointsGroup;
    @FXML
    MenuButton selectFileDir;

    FileChooser fileChooser = new FileChooser();

    // add menu items to menu 
    //FileOutputStream fO;
    //private boolean checkImport = false;
    private String checkImport = "src/database/questions.txt";
    int i = 0;

    @FXML
    public void handleSaveSettings() throws IOException {

        //Scrittura su file delle impostazioni
        try {

            // Scrive il livello di difficoltà selezionato
            String file = "src/database/settings.txt";
            FileWriter fileWriter = new FileWriter(file);
            RadioButton buttonDifficoulty = (RadioButton) difficultyLevel.getSelectedToggle();
            String valueDifficoulty = buttonDifficoulty.getText();
            fileWriter.write(valueDifficoulty + "\n");

            //Scrive la quantita di domande che si vuole utilizzare
            if (Integer.parseInt(questionsAmount.getText()) > 42
                    || Integer.parseInt(questionsAmount.getText()) <= 0) {
                labelError.setText("Quantità non valida, setto\ni parametri di default.");
                fileWriter.write("10\n");
            } else if (Integer.parseInt(questionsAmount.getText()) % 2 != 0) {
                labelError.setText("E' preferibile l'uso dei pari,\nun pò di fair play!");
                fileWriter.write(questionsAmount.getText() + "\n");
            } else {
                labelError.setText("OK!");
                fileWriter.write(questionsAmount.getText() + "\n");
            }

            //Scrive la scala di punti selezionata
            RadioButton buttonPoints = (RadioButton) pointsGroup.getSelectedToggle();
            String valuePoints = buttonPoints.getText();

            // La scelta del "si" porta il salvataggio come "true", il "no" del "false".
            if (valuePoints.equalsIgnoreCase("si")) {
                fileWriter.write("true\n");
            } else {
                fileWriter.write("false\n");
            }
            labelSaved.setText("Impostazioni salvate");

                fileWriter.write(checkImport);
            

            fileWriter.close();

        } catch (IOException ex) {
            System.out.println(ex);
        }

        // Salva il numero di domande a cui rispondere.
        // Verifica la validità dei valori inseriti e lo segnala all'utente.
    }

    @FXML
    public void handleImport() throws IOException {

        File selectedFile = fileChooser.showOpenDialog(null);

        if (selectedFile != null) {
            File dest = new File("src/database/questions" + i + ".txt");
            i++;
            Files.copy(selectedFile.toPath(), dest.toPath());
            
            if (checkImportedFile(new File(dest.getPath())) != true) {
                labelSaved.setText("File non compatibile");
            } else {
                
                //selectedFile.renameTo(new File("src/database/questions1.txt"));
                //checkImport = true;
                checkImport = dest.getPath();
                filePath.setText(checkImport);
            }
        }

        System.out.println(selectedFile);

    }

    @FXML
    public void reset() throws IOException {

        String file = "src/database/settings.txt";
        FileWriter fW = new FileWriter(file);
        fW.write("MIX\n");
        fW.write("10\n");
        fW.write("false\n");
        fW.write("src/database/questions.txt");
        fW.close();
        labelSaved.setText("Reset completato");

    }

    @FXML
    public boolean checkImportedFile(File file) throws IOException {
        boolean validFile = false;
        ArrayList<String> x = new ArrayList<>();
        ArrayList<String> checkLine = new ArrayList<>();
        ArrayList<String> checkAnswers = new ArrayList<>();
        String level = "";

        try (Scanner reader = new Scanner(file)) {
            while (reader.hasNextLine()) {
                String q = reader.nextLine();
                x.add(q);
            }
        } catch (IOException ex) {
            System.out.println(ex);
        }
        StringTokenizer st;
        for (int i = 0; i < x.size()-1; i++) {

            st = new StringTokenizer(x.get(i), ";");
            while (st.hasMoreTokens()) {
                checkLine.add(st.nextToken());
                
            }
            System.out.println("CheckLine:   "+checkLine);
            if (checkLine.size() != 3) {
                validFile = false;
            } else {

                st = new StringTokenizer(checkLine.get(1), "-");
                while (st.hasMoreTokens()) {
                    checkAnswers.add(st.nextToken());
                }
                System.out.println("checkAnsw :   "+ checkAnswers);
                if (checkAnswers.size() != 4) {
                    validFile = false;
                } else {
                    level = checkLine.get(2);
                    System.out.println("Level :  " + level);
                    if (level.equalsIgnoreCase("FACILE") || level.equalsIgnoreCase("MIX") || level.equalsIgnoreCase("DIFFICILE") || level.equalsIgnoreCase("MEDIA")) {
                        validFile = true;
                        System.out.println(validFile);
                    } else {
                        validFile = false;
                    }
                }

            }
            checkLine.clear();
            checkAnswers.clear();
            level = "";
        }
        System.out.println(validFile);
        return validFile;
    }

    @FXML
    public void handleGoBack(ActionEvent click) throws IOException {
        switchScene(click, "src/main_menu.fxml");
    }
}
