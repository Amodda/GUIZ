package controllers;

import java.io.File;
import java.io.FileOutputStream;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;

import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import javafx.stage.FileChooser;

// Gestisce il salvataggio delle "Impostazioni" una delle parti più importanti dell'intero programma.
// Tutte le scelte fatte dall'utente nella GUI vengono salvate in differenti file di testo i cui dati
// verranno letti ed elaborati dal GameController.
public class ControlPanelBoard implements SceneSwitch {

    @FXML
    TextField questionsAmount;
    @FXML
    RadioButton easyRadio;
    @FXML
    RadioButton mediumRadio;
    @FXML
    RadioButton hardRadio;
    @FXML
    RadioButton mixRadio;
    @FXML
    RadioButton yesRadio;
    @FXML
    RadioButton noRadio;
    @FXML
    Label labelSaved;
    @FXML
    Label labelError;
    @FXML
    ToggleGroup difficultyLevel;
    @FXML
    ToggleGroup pointsGroup;

    FileChooser fileChooser = new FileChooser();
    //FileOutputStream fO;

    //private boolean checkImport = false;
    private String checkImport = "a";
    int i = 0;

    @FXML
    public void handleSaveSettings() throws IOException {

        //Scrittura su file delle impostazioni
        
        try {
            
            // Scrive il livello di difficoltà selezionato
            String file = "src/database/settings.txt";
            FileWriter fileWriter = new FileWriter(file);
            RadioButton buttonDifficoulty = (RadioButton) difficultyLevel.getSelectedToggle();
            String valueDifficoulty = buttonDifficoulty.getText();
            fileWriter.write(valueDifficoulty + "\n");
            
            //Scrive la quantita di domande che si vuole utilizzare
            
            if (Integer.parseInt(questionsAmount.getText()) > 42
                    || Integer.parseInt(questionsAmount.getText()) <= 0) {
                labelError.setText("Quantità non valida, setto\ni parametri di default.");
                fileWriter.write("10\n");
            } else if (Integer.parseInt(questionsAmount.getText()) % 2 != 0) {
                labelError.setText("E' preferibile l'uso dei pari,\nun pò di fair play!");
                fileWriter.write(questionsAmount.getText() +"\n");
            } else {
                labelError.setText("OK!");
                fileWriter.write(questionsAmount.getText()  + "\n");
            }
            
            //Scrive la scala di punti selezionata
            
            RadioButton buttonPoints = (RadioButton) pointsGroup.getSelectedToggle();
            String valuePoints = buttonPoints.getText();

            // La scelta del "si" porta il salvataggio come "true", il "no" del "false".
            if (valuePoints.equalsIgnoreCase("si")) {
                fileWriter.write("true\n");
            } else {
                fileWriter.write("false\n");
            }
            labelSaved.setText("Impostazioni salvate");
            
            
            fileWriter.close();
            
        } catch (IOException ex) {
            System.out.println(ex);
        }

        // Salva il numero di domande a cui rispondere.
        // Verifica la validità dei valori inseriti e lo segnala all'utente.
        
    }

    @FXML
    public void handleImport() throws IOException {

        File selectedFile = fileChooser.showOpenDialog(null);

        if (selectedFile != null) {
            File dest = new File("src/database/questions" + i + " .txt");
            i++;
            Files.copy(selectedFile.toPath(), dest.toPath());
//selectedFile.renameTo(new File("src/database/questions1.txt"));
            //checkImport = true;
            checkImport = "hello";
        }

        System.out.println(selectedFile);
        
    }

    public String readImport() {
        return checkImport;
    }

    @FXML
    public void handleGoBack(ActionEvent click) throws IOException {
        switchScene(click, "src/main_menu.fxml");
    }
}
