package handler;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

// Inizializza il contenuto dei file amount.txt, difficulty.txt, points.txt
// in modo che ad ogni partita vengano usati i parametri di default e non quelli
// salvati nella partita precedente.
public class DataWriter {

    private static final File settings = new File("src/database/settings.txt");

    PrintWriter outputStream = null;

    {
        try {
            outputStream = new PrintWriter(settings);
        } catch (FileNotFoundException ex) {
        }

        outputStream.print("MIX\n");
        outputStream.print("10\n");
        outputStream.print("false");
        outputStream.close();

    }
}
