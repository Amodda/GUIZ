package handler;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

// Legge il contenuto dei vari file di testo che contengono, domande, risposte, livello di difficoltà,
// punteggio di ciascuna domanda, il numero di domande a cui rispondere.
// Le informazioni verranno elaborate nel GameController.
public class DataReader {

    private static final File questionsFile = new File("src/database/questions.txt");
    private static final File settings = new File("src/database/settings.txt");

    public static ArrayList<String> readQuestions() {
        ArrayList<String> x;
        x = DataReader.getStrings(settings);
        File questions = new File(x.get(3));
        return getStrings(questions);
    }

    public static ArrayList<String> readSettings() {
        return getStrings(settings);
    }

    private static ArrayList<String> getStrings(File xFile) {
        ArrayList<String> x = new ArrayList<>();

        try (Scanner reader = new Scanner(xFile)) {
            while (reader.hasNextLine()) {
                String q = reader.nextLine();
                x.add(q);
            }
        } catch (IOException ex) {
            System.out.println(ex);
        }
        return x;
    }
}
